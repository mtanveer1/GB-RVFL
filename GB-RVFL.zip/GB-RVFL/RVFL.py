import numpy as np
import time

def selu(x):
    alpha = 1.6732632423543772848170429916717
    scale = 1.0507009873554804934193349852946
    
    def y(x):
        return (scale * x) * (x > 0) + (scale * alpha * (np.exp(x) - 1)) * (x <= 0)
    
    result = y(x)
    return result

def relu(x):
    return np.maximum(0, x)

def sigmoid(x):
    return 1 / (1 + np.e ** (-x))

def hardlim(x):
    return (np.sign(x) + 1) / 2

def tribas(x):
    return np.maximum(1 - np.abs(x), 0)

def radbas(x):
    return np.exp(-(x**2))

def leaky_relu(x):
    x[x >= 0] = x[x >= 0]
    x[x < 0] = x[x < 0] / 10.0
    return x

import numpy as np

def Evaluate(ACTUAL, PREDICTED):
    idx = (ACTUAL == 1)
    p = np.sum(idx)
    n = np.sum(~idx)
    N = p + n
    tp = np.sum(np.logical_and(ACTUAL[idx] == 1, PREDICTED[idx] == 1))
    tn = np.sum(np.logical_and(ACTUAL[~idx] == 0, PREDICTED[~idx] == 0))
    fp = n - tn
    fn = p - tp
    tp_rate = tp / p if p != 0 else 0
    tn_rate = tn / n if n != 0 else 0
    accuracy = 100 * (tp + tn) / N
    sensitivity = 100 * tp_rate
    specificity = 100 * tn_rate
    precision = 100 * tp / (tp + fp) if (tp + fp) != 0 else 0
    recall = sensitivity
    f_measure = 2 * ((precision * sensitivity) / (precision + sensitivity)) if (precision + sensitivity) != 0 else 0
    gmean = 100 * np.sqrt(tp_rate * tn_rate)
    
    EVAL = [accuracy, sensitivity, specificity, precision, recall, f_measure, gmean, tp, tn, fp, fn]
    return EVAL

def one_hot(x, n_class):
    y = np.zeros([len(x), n_class])
    U_dataY_train = np.array([0,1])
    for i in range(n_class):
        idx= (x == U_dataY_train[i])
        y[idx,i]=1
    return y

#idx= np.array([np.where(U_dataY_train(i) == x)])


def RVFL_train(train_data, test_data, C,N,activation):
    # np.random.seed(2)
    

    start = time.time()
    trainX=train_data[:,:-1]
    trainY=train_data[:,-1]

    s = 0.1
    
    Nsample, Nfea = trainX.shape

    nclass = 2
    dataY_train_temp = one_hot(trainY,nclass)

    W = np.random.rand(Nfea, N) * 2 - 1
    b = s * np.random.rand(1, N)
    X1 = np.dot(trainX, W) + np.tile(b, (Nsample, 1))

    if activation == 1:
        X1 = selu(X1)
    elif activation == 2:
        X1 = relu(X1)
    elif activation == 3:
        X1 = sigmoid(X1)
    elif activation == 4:
        X1 = np.sin(X1)
    elif activation == 5:
        X1 = hardlim(X1)
    elif activation == 6:
        X1 = tribas(X1)
    elif activation == 7:
        X1 = radbas(X1)
    elif activation == 8:
        X1 = np.sign(X1)
    elif activation == 9:
        X1 = leaky_relu(X1)
    elif activation == 10:
        X1 = np.tanh(X1)
    
    X = np.concatenate((trainX, X1), axis=1)
    X = np.hstack((X, np.ones((Nsample, 1))))  # Bias in the output layer
    
    if X.shape[1] < Nsample:
        beta = np.dot(np.linalg.inv(np.eye(X.shape[1]) * (1 / C) + np.dot(X.T, X)), np.dot(X.T, dataY_train_temp))
    else:
        beta = np.dot(X.T, np.dot(np.linalg.inv(np.eye(X.shape[0]) * (1 / C) + np.dot(X, X.T)),dataY_train_temp))
    

    # Test

    X=test_data[:,:-1]
    Y=test_data[:,-1]
    
    Nsample = X.shape[0]

    # Test Data

    X1 = np.dot(X, W) + np.tile(b, (Nsample, 1))

    if activation == 1:
        X1 = selu(X1)
    elif activation == 2:
        X1 = relu(X1)
    elif activation == 3:
        X1 = sigmoid(X1)
    elif activation == 4:
        X1 = np.sin(X1)
    elif activation == 5:
        X1 = hardlim(X1)
    elif activation == 6:
        X1 = tribas(X1)
    elif activation == 7:
        X1 = radbas(X1)
    elif activation == 8:
        X1 = np.sign(X1)
    elif activation == 9:
        X1 = leaky_relu(X1)
    elif activation == 10:
        X1 = np.tanh(X1)

    X1 = np.hstack((X1, np.ones((Nsample, 1))))
    X = np.hstack((X, X1))
    rawScore = np.dot(X, beta)

    Validation_label = np.argmax(rawScore, axis=1) 

    EVAL_Validation = Evaluate(Y, Validation_label)
    end = time.time()
    Time=end - start
    return EVAL_Validation,Time
