import os
import numpy as np
from RVFL import RVFL_train
from gen_ball import gen_balls
from sklearn.model_selection import KFold

directory = './Dat'
file_list = os.listdir(directory)

for file_name in file_list:
    if file_name.endswith(".csv"):
        file_path = os.path.join(directory, file_name)
        print(directory)
        print(file_name)
        file_data = np.loadtxt(file_path, delimiter=',')
        
        m, n = file_data.shape
        for i in range(m):
            if file_data[i, n-1] == 0:
                file_data[i, n-1] = -1
    
        np.random.seed(0)
        indices = np.random.permutation(m)
        file_data = file_data[indices]
        AA_train=file_data[0:int(m*(1-0.30))]
        A_test=file_data[int(m * (1-0.30)):]

        m1, n1 = A_test.shape
        for i in range(m1):
            if A_test[i, n1-1] == -1:
                A_test[i, n1-1] = 0
        
        pur = 1 - (0.015 * 5)                      
        num = 2
        A_train = gen_balls(AA_train, pur=pur, delbals=num)
        
        Radius=[]
        for i in A_train:
            Radius.append(i[1])
        Center=[]
        for ii in A_train:
            Center.append(ii[0])
        Label=[]
        for iii in A_train:
            Label.append(iii[-1])
        Radius=np.array(Radius)

        Center=np.array(Center)
        Label=np.array(Label)
        
        A_train=np.hstack((Center,Label.reshape(Label.shape[0], 1)))

        m, n = A_train.shape
        for i in range(m):
            if A_train[i, n-1] == -1:
                A_train[i, n-1] = 0


        c1_best=0.01
        N_best=203
        Act_best=8

        Eval, Test_time = RVFL_train(A_train, A_test, c1_best, N_best,Act_best)

        Test_accuracy=Eval[0]
        print(Test_accuracy)
