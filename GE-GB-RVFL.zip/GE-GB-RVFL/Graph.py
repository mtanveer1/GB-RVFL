import numpy as np
from scipy.linalg import pinv


def matrices_LDA(data, lbls):
    noOfClasses = len(np.unique(lbls))
    N = data.shape[1]
    W = np.zeros((N, N))

    for k in range(1, noOfClasses + 1):
        curr_ind = np.where(lbls == k)[0]
        n_k = len(curr_ind)
        e_k = np.zeros((N, 1))
        e_k[curr_ind] = 1.0

        try:
            W = W + (1 / n_k) * (e_k @ e_k.T)
        except:
            print('ERRORs')

    Llda_w = np.eye(N) - W
    Llda_b = W - (1 / N) * np.ones((N, N))

    Slda_w = data @ Llda_w @ data.T
    Slda_b = data @ Llda_b @ data.T

    return Slda_w, Slda_b

def matrices_LFDA(data, lbls):
    N = data.shape[1]
    Dmat = np.sum(data.T ** 2, axis=1)[:, np.newaxis] + np.sum(data.T ** 2, axis=1) - 2 * (data.T @ data)
    sigma2 = np.mean(np.mean(Dmat))
    Amat = np.exp(-Dmat / (2 * sigma2))

    Wlfda_b = np.zeros_like(Amat)
    Wlfda_w = np.zeros_like(Amat)

    for ii in range(len(lbls)):
        curr_ind = np.where(lbls == lbls[ii])[0]
        other_ind = np.where(lbls != lbls[ii])[0]
        Wlfda_w[ii, curr_ind] = Amat[ii, curr_ind] / len(curr_ind)
        Wlfda_b[ii, curr_ind] = Amat[ii, curr_ind] * (1 / N - 1 / len(curr_ind))
        Wlfda_b[ii, other_ind] = 1 / N

    Wlfda_w = (Wlfda_w + Wlfda_w.T) / 2
    Wlfda_b = (Wlfda_b + Wlfda_b.T) / 2

    Dlfda_w = np.sum(Wlfda_w, axis=1)
    Llfda_w = np.diag(Dlfda_w) - Wlfda_w

    Dlfda_b = np.sum(Wlfda_b, axis=1)
    Llfda_b = np.diag(Dlfda_b) - Wlfda_b

    Slfda_w = data @ Llfda_w @ data.T
    Slfda_b = data @ Llfda_b @ data.T

    return Slfda_w, Slfda_b


def matrices_MDA(data, lbls, kNN):
    N = data.shape[1]
    Dmat = np.sum(data.T ** 2, axis=1)[:, np.newaxis] + np.sum(data.T ** 2, axis=1) - 2 * (data.T @ data)
    
    Wmda_b = np.zeros_like(Dmat)
    Wmda_w = np.zeros_like(Dmat)

    for ii in range(len(lbls)):
        curr_ind = np.where(lbls == lbls[ii])[0]
        sorted_indices = np.argsort(Dmat[ii, curr_ind])

        try:
            knn_ind_w = sorted_indices[:kNN]
        except:
            kNN = len(sorted_indices)
            knn_ind_w = sorted_indices[:kNN]

        Wmda_w[ii, curr_ind[knn_ind_w]] = 1

        curr_ind = np.where(lbls != lbls[ii])[0]
        sorted_indices = np.argsort(Dmat[ii, curr_ind])

        knn_ind_b = sorted_indices[:kNN]
        Wmda_b[ii, curr_ind[knn_ind_b]] = 1

    Wmda_w = (Wmda_w + Wmda_w.T)
    Wmda_w[Wmda_w != 0] = 1.0

    Wmda_b = (Wmda_b + Wmda_b.T)
    Wmda_b[Wmda_b != 0] = 1.0

    Dmda_w = np.sum(Wmda_w, axis=1)
    Lmda_w = np.diag(Dmda_w) - Wmda_w

    Dmda_b = np.sum(Wmda_b, axis=1)
    Lmda_b = np.diag(Dmda_b) - Wmda_b

    Smda_w = data @ Lmda_w @ data.T
    Smda_b = data @ Lmda_b @ data.T

    return Smda_w, Smda_b


def calc_ge_data2(train_data, train_lbls, graph_type, kNN):
    # train_data --> DxN matrix (N training samples)
    # train_lbls --> Nx1 training label vector
    # graph_type --> graph type (1->LDA, 2->LFDA, 3->MDA)
    # kNN --> NN parameter for MDA graph

 
    D, N = train_data.shape
    

    # calculate graph matrices
    if graph_type == 1:  # LDA
        S_w, S_b = matrices_LDA(train_data, train_lbls)
    elif graph_type == 2:  # LFDA
        S_w, S_b = matrices_LFDA(train_data, train_lbls)
    elif graph_type == 3:  # MDA
        S_w, S_b = matrices_MDA(train_data, train_lbls, kNN)

    # calculate modified samples
    Rval = 1e-3
    S = pinv(S_b + Rval * np.eye(S_b.shape[0])) @ S_w

    return S
